# --- Freqtrade Kütüphaneleri ---
from freqtrade.strategy import IStrategy
from pandas import DataFrame
import talib.abstract as ta

class rsi_sma_strategy(IStrategy):
    """
    Bu bizim ikinci ve daha akıllı stratejimiz.
    MANTIĞI:
    - ALIM SİNYALİ: Fiyat uzun vadeli trendin (SMA200) üzerindeyken,
                    RSI 30'un altına düşerse (düşüşten alım fırsatı).
    - SATIM SİNYALİ: RSI 70'in üzerine çıktığında (aşırı alım).
    """
    INTERFACE_VERSION = 3
    timeframe = '5m'

    # Kâr alma ayarları
    minimal_roi = {
        "60": 0.03,
        "120": 0.02,
        "0": 0.05
    }

    # Zarar durdurma ayarı
    stoploss = -0.10

    # Stratejinin genel davranışını belirleyen ayarlar
    process_only_new_candles = True
    use_exit_signal = True
    exit_profit_only = False
    ignore_roi_if_entry_signal = False
    startup_trend_req = 200 # En uzun indikatörümüz SMA200 olduğu için

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        Strateji için gerekli olan indikatörleri hesaplar: RSI ve SMA200.
        """
        # RSI (Relative Strength Index)
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)

        # SMA (Simple Moving Average) - 200 periyotluk
        dataframe['sma_200'] = ta.SMA(dataframe, timeperiod=200)
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        Alım sinyali koşullarını belirler.
        """
        dataframe.loc[
            (
                # KOŞUL 1: RSI 30'un altına düşmeli
                (dataframe['rsi'] < 30) &
                # KOŞUL 2: Fiyat, 200 periyotluk SMA'nın üzerinde olmalı (Yükseliş Trendi)
                (dataframe['close'] > dataframe['sma_200']) &
                (dataframe['volume'] > 0)
            ),
            'enter_long'] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        Satım sinyali koşullarını belirler.
        """
        dataframe.loc[
            (
                # KOŞUL 1: RSI 70'in üzerine çıkmalı
                (dataframe['rsi'] > 70) &
                (dataframe['volume'] > 0)
            ),
            'exit_long'] = 1
        return dataframe
# --- Hyperopt Ayarları ---
# Bu bölüm, Freqtrade'in stratejinin en iyi versiyonunu bulmasını sağlar.

# from freqtrade.strategy import CategoricalParameter, DecimalParameter, IntParameter

class rsi_sma_strategy(IStrategy):

    # ... (dosyanın geri kalanı burada, o kısma dokunmayın) ...

    # Hyperopt için optimize edilecek parametreleri tanımlayalım:
    
    # ALIM AYARLARI
    buy_rsi = IntParameter(10, 40, default=30, space='buy')
    
    # SATIM AYARLARI
    sell_rsi = IntParameter(60, 90, default=70, space='sell')