# --- Do not remove these imports ---
import numpy as np
import pandas as pd
from pandas import DataFrame
from freqtrade.strategy import IStrategy

# --------------------------------
# Add your lib to import here
import talib.abstract as ta
from technical import qtpylib


class rsi_sma_bb_strategy(IStrategy):
    """
    Bu bizim üçüncü ve en gelişmiş stratejimiz (v3.0).
    MANTIĞI:
    - ALIM: Fiyat SMA200'ün üzerindeyken (yükseliş trendi),
            RSI 30'un altına düşerse (aşırı satım) VE
            Fiyat Bollinger Alt Bandına dokunursa (istatistiksel düşüş).
    - SATIM: RSI 70'in üzerine çıktığında (aşırı alım).
    """
    INTERFACE_VERSION = 3
    timeframe = '5m'

    # Kâr alma ayarları
    minimal_roi = {
        "0": 0.05
    }

    # Zarar durdurma ayarı
    stoploss = -0.10

    process_only_new_candles = True
    use_exit_signal = True
    exit_profit_only = False
    ignore_roi_if_entry_signal = False
    startup_trend_req = 200  # En uzun indikatörümüz SMA200

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        Strateji için gerekli olan 3 indikatörü hesaplar.
        """
        # Bollinger Bands
        bollinger = qtpylib.bollinger_bands(qtpylib.typical_price(dataframe), window=20, stds=2)
        dataframe['bb_lowerband'] = bollinger['lower']
        
        # RSI
        dataframe['rsi'] = ta.RSI(dataframe)
        
        # SMA - 200
        dataframe['sma_200'] = ta.SMA(dataframe, timeperiod=200)

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        Alım sinyali için 3 koşulu birden kontrol eder.
        """
        dataframe.loc[
            (
                (dataframe['rsi'] < 30) &
                (dataframe['close'] > dataframe['sma_200']) &
                (dataframe['close'] <= dataframe['bb_lowerband']) &
                (dataframe['volume'] > 0)
            ),
            'enter_long'] = 1

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        Satım sinyalini belirler.
        """
        dataframe.loc[
            (
                (dataframe['rsi'] > 70) &
                (dataframe['volume'] > 0)
            ),
            'exit_long'] = 1
        return dataframe