# --- Do not remove these imports ---
from freqtrade.strategy import IStrategy, IntParameter
from pandas import DataFrame
# --------------------------------
# Add your lib to import here
import talib.abstract as ta
from technical import qtpylib

class freqai_strategy(IStrategy):
    """
    Bu bizim ilk FreqAI stratejimiz.
    Amacımız, teknik indikatörleri birer "özellik" olarak kullanarak,
    gelecekteki fiyat artışını tahmin eden bir model eğitmektir.
    """
    INTERFACE_VERSION = 3
    timeframe = '5m'

    # FreqAI için gerekli olan ayarlar.
    can_short = False
    use_exit_signal = True
    startup_trend_req = 200

    # Hyperopt parametreleri (şimdilik devre dışı)
    # buy_rsi = IntParameter(10, 40, default=30, space='buy')
    # sell_rsi = IntParameter(60, 90, default=70, space='sell')

    # FreqAI Modelinin tahmin yapmasını istediğimiz hedef (Label)
    # Bu örnekte: "Gelecek 20 mum (100 dakika) içinde en yüksek fiyat,
    # şimdikinden %3 daha fazla olacak mı?" sorusunun cevabını tahmin et.
    def feature_engineering_expand_lookahead(self, dataframe: DataFrame, period: int, **kwargs) -> DataFrame:
        dataframe[f'future_max_{period}'] = dataframe['high'].rolling(period).max().shift(-period)
        dataframe[f'future_min_{period}'] = dataframe['low'].rolling(period).min().shift(-period)
        dataframe[f'future_exit_price_{period}'] = dataframe['close'].shift(-period)
        return dataframe

    # FreqAI Modelinin kullanacağı özellikler (Features)
    # Bizim daha önceki stratejilerimizdeki tüm indikatörleri buraya ekliyoruz.
    def feature_engineering_expand_basic(self, dataframe: DataFrame, metadata: dict, **kwargs) -> DataFrame:
        dataframe['rsi'] = ta.RSI(dataframe)
        dataframe['sma_200'] = ta.SMA(dataframe, timeperiod=200)
        bollinger = qtpylib.bollinger_bands(qtpylib.typical_price(dataframe), window=20, stds=2)
        dataframe['bb_lowerband'] = bollinger['lower']
        dataframe['bb_middleband'] = bollinger['mid']
        dataframe['bb_upperband'] = bollinger['upper']
        return dataframe

    # FreqAI'a hangi özellik setlerini kullanacağını söylüyoruz.
    def set_freqai_targets(self, dataframe: DataFrame, **kwargs):
        dataframe['&s-future_max_20'] = (
            (dataframe['future_max_20'] > dataframe['close'] * 1.03)
        ).astype(int)
        return dataframe

    # --- Standart Strateji Fonksiyonları (FreqAI kullanırken genellikle boş bırakılır) ---
    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        return dataframe